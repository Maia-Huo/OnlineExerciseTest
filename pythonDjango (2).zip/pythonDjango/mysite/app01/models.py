
from django.db import models

# Create your models here.

class st(models.Model):

    # num = models.IntegerField(verbose_name="教工号", default="114514")  # 学号
    pas = models.CharField(max_length=16, verbose_name="密码")  # 密码
    account = models.IntegerField(primary_key=True, verbose_name="账号")  # 账号

class topic_1(models.Model):
    title = models.TextField(verbose_name="题目")
    optionsA = models.TextField(verbose_name="选项1")
    optionsB = models.TextField(verbose_name="选项2")
    optionsC = models.TextField(verbose_name="选项3")
    optionsD = models.TextField(verbose_name="选项4")
    aws = models.CharField(max_length=1, verbose_name="答案")


class topic_2(models.Model):
    title = models.TextField(verbose_name="题目")
    optionsA = models.TextField(verbose_name="选项1")
    optionsB = models.TextField(verbose_name="选项2")
    optionsC = models.TextField(verbose_name="选项3")
    optionsD = models.TextField(verbose_name="选项4")
    aws = models.CharField(max_length=4, verbose_name="答案")


class topic_3(models.Model):
    title = models.TextField(verbose_name="题目")
    aws = models.TextField(verbose_name="答案")
