from django.http import HttpResponse
from django.shortcuts import render, redirect
from app01.models import st, topic_1, topic_2, topic_3
from django.contrib import messages
from django import forms

class Form1(forms.ModelForm):
    class Meta:
        model = topic_1
        fields = ["title", "optionsA", "optionsB", "optionsC", "optionsD", "aws"]


class Form2(forms.ModelForm):
    class Meta:
        model = topic_2
        fields = ["title", "optionsA", "optionsB", "optionsC", "optionsD", "aws"]


class Form3(forms.ModelForm):
    class Meta:
        model = topic_3
        fields = ["title", "aws"]

def login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    else:
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:  # 存放可能出现异常的代码 查询数据多个条件时默认是并且的关系
            user = st.objects.get(account=username)#objects.get()方法是从数据库的取得一个匹配的结果，返回一个对象，如果不存在会报错
            # 当输入的用户名在数据库里查询不到，说明try里面的代码存在异常
            # 执行万能异常里面的语句
        except Exception as e:  # 捕获异常将异常存到e里
            print(e)
            messages.warning(request, '用户名不存在')
            return redirect('/login/')
        # 如果用户名对，就判断密码有没有输入正确
        if password != user.pas:
            # return HttpResponse("用户名和密码不匹配")
            messages.warning(request,'用户名和密码不匹配')
            return redirect('/login/')

        else:
            # messages.success(request, '成功登录')
            return redirect('/select/')



def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')

    else:
        # 获取用户提交的数据
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm = request.POST.get('confirm-password')
        print(username, password)
        users = st.objects.all()
        # 添加到数据库
        if password==confirm:
            for i in users:
                if username == i.account:
                    # return HttpResponse("用户已存在")
                    messages.warning(request, '用户已存在')
                    return redirect('/signup/')
            try:
                st.objects.create(account=username, pas=password)
            except Exception as e:
                print(e)
                # return HttpResponse("注册失败")
                messages.warning(request, '用户已存在')
                return redirect('/signup/')
            return render(request, 'login.html')
        else:
            messages.warning(request,'两次密码不一致')
            return redirect('/signup/')


def upload1(request):
    if request.method == 'GET':#如果以GET请求访问,则表示是第一次进入此界面,此时直接返回到对应的前端界面
        return render(request, 'upload1.html')

    else:#POST请求,表示前端提交form表单的数据到后端
        form = Form1(data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '上传成功')
            return redirect("/show/")
        return render(request, 'upload1.html', {'form': form})


def upload2(request):
    if request.method == 'GET':
        return render(request, 'upload2.html')

    else:
        form = Form2(data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '上传成功')
            return redirect("/show/")
        return render(request, 'upload2.html', {'form': form})


def upload3(request):
    if request.method == 'GET':
        return render(request, 'upload3.html')

    else:
        form = Form3(data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '上传成功')
            return redirect("/show/")
        return render(request, 'upload3.html', {'form': form})


# def show(request):
#     queryset1 = topic_1.objects.all()
#     queryset2 = topic_2.objects.all()
#     queryset3 = topic_3.objects.all()
#     return render(request, "show.html", {'queryset1': queryset1, 'queryset2': queryset2, 'queryset3': queryset3})

def show(request):
    queryset1 = topic_1.objects.all()
    queryset2 = topic_2.objects.all()
    queryset3 = topic_3.objects.all()
    queryset = [queryset1, queryset2, queryset3]
    return render(request, "show.html", {'queryset': queryset})

def index(request):
    queryset1 = topic_1.objects.all()
    queryset2 = topic_2.objects.all()
    queryset3 = topic_3.objects.all()
    return render(request, 'index.html',{'queryset1': queryset1, 'queryset2': queryset2, 'queryset3': queryset3})

def teacher(request):
    if request.method == 'GET':
        return render(request, 'teacher.html')
    else:
        num1 = request.POST.get('num')
        if num1 == '114514':
            messages.success(request, '成功登录')
            return redirect('/show/')
        else:
            messages.warning(request, '密码不正确')
            return redirect('/teacher/')

def select(request):
    return render(request, 'select.html')


def delete1(request):
    nid = request.GET.get('nid')
    topic_1.objects.filter(id=nid).delete()
    return redirect("/show/")


def delete2(request):
    nid = request.GET.get('nid')
    topic_2.objects.filter(id=nid).delete()
    return redirect("/show/")


def delete3(request):
    nid = request.GET.get('nid')
    topic_3.objects.filter(id=nid).delete()
    return redirect("/show/")


def edit1(request, nid):
    if request.method == 'GET':
        row_object = topic_1.objects.filter(id=nid).first()
        return render(request, 'edit1.html', {'row_object': row_object})

    else:
        row_object = topic_1.objects.filter(id=nid).first()
        title1 = request.POST.get('title')
        options_a = request.POST.get("optionsA")
        options_b = request.POST.get("optionsB")
        options_c = request.POST.get("optionsC")
        options_d = request.POST.get("optionsD")
        aws1 = request.POST.get('aws')

        form = Form1(data=request.POST)
        if form.is_valid():
            topic_1.objects.filter(id=nid).update(title=title1, optionsA=options_a, optionsB=options_b, optionsC=options_c, optionsD=options_d, aws=aws1)
            topic_1.objects.filter(id=nid).first()
            messages.success(request, '单选题修改成功')
            return redirect("/show/")
        return render(request, 'edit1.html', {'form': form, 'row_object': row_object})


def edit2(request, nid):
    if request.method == 'GET':
        row_object = topic_2.objects.filter(id=nid).first()
        return render(request, 'edit2.html', {'row_object': row_object})

    else:
        row_object = topic_2.objects.filter(id=nid).first()
        title1 = request.POST.get('title')
        options_a = request.POST.get("optionsA")
        options_b = request.POST.get("optionsB")
        options_c = request.POST.get("optionsC")
        options_d = request.POST.get("optionsD")
        aws1 = request.POST.get('aws')

        form = Form2(data=request.POST)
        if form.is_valid():
            topic_2.objects.filter(id=nid).update(title=title1, optionsA=options_a, optionsB=options_b, optionsC=options_c, optionsD=options_d, aws=aws1)
            topic_2.objects.filter(id=nid).first()
            messages.success(request, '多选题修改成功')
            return redirect("/show/")
        return render(request, 'edit2.html', {'form': form, 'row_object': row_object})


def edit3(request, nid):
    if request.method == 'GET':
        row_object = topic_3.objects.filter(id=nid).first()
        return render(request, 'edit3.html', {'row_object': row_object})

    else:
        row_object = topic_3.objects.filter(id=nid).first()
        title1 = request.POST.get('title')
        aws1 = request.POST.get('aws')

        form = Form3(data=request.POST)
        if form.is_valid():
            topic_3.objects.filter(id=nid).update(title=title1,  aws=aws1)
            topic_3.objects.filter(id=nid).first()
            messages.success(request, '填空题修改成功')
            return redirect("/show/")
        return render(request, 'edit3.html', {'form': form, 'row_object': row_object})

def file1(request):

    from openpyxl import load_workbook

    #获取用户上传的文件对象
    file_object = request.FILES.get('exc')
    print(type(file_object))

    #对象传递给openpyxl，由openpyxl读取文件内容
    wb = load_workbook(file_object)
    sheet = wb.worksheets[0]

    for row in sheet.iter_rows(min_row=2):
        title1 = row[0].value
        options_a = row[1].value
        options_b = row[2].value
        options_c = row[3].value
        options_d = row[4].value
        aws1 = row[5].value
        topic_1.objects.create(title=title1, optionsA=options_a, optionsB=options_b, optionsC=options_c,
                               optionsD=options_d, aws=aws1)
    return redirect("/show/")


def file2(request):

    from openpyxl import load_workbook

    #获取用户上传的文件对象
    file_object = request.FILES.get('exc')
    print(type(file_object))

    #对象传递给openpyxl，由openpyxl读取文件内容
    wb = load_workbook(file_object)
    sheet = wb.worksheets[0]

    for row in sheet.iter_rows(min_row=2):
        title1 = row[0].value
        options_a = row[1].value
        options_b = row[2].value
        options_c = row[3].value
        options_d = row[4].value
        aws1 = row[5].value
        topic_2.objects.create(title=title1, optionsA=options_a, optionsB=options_b, optionsC=options_c,
                               optionsD=options_d, aws=aws1)
    return redirect("/show/")

def file3(request):

    from openpyxl import load_workbook

    #获取用户上传的文件对象
    file_object = request.FILES.get('exc')
    print(type(file_object))

    #对象传递给openpyxl，由openpyxl读取文件内容
    wb = load_workbook(file_object)
    sheet = wb.worksheets[0]

    for row in sheet.iter_rows(min_row=2):
        title1 = row[0].value
        aws1 = row[1].value
        topic_3.objects.create(title=title1, aws=aws1)
    return redirect("/show/")
