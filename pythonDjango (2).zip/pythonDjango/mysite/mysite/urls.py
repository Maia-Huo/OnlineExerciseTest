"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app01 import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.login),
    path('login/', views.login),
    path('signup/', views.signup),
    path('index/', views.index),
    path('show/', views.show),
    path('show/upload1.html/',views.upload1),
    path('show/upload2.html/',views.upload2),
    path('show/upload3.html/',views.upload3),
    path('upload1/', views.upload1),
    path('upload2/', views.upload2),
    path('upload3/', views.upload3),
    path('teacher/', views.teacher),
    path('select/', views.select),
    path('show/delete1/', views.delete1),
    path('show/delete2/', views.delete2),
    path('show/delete3/', views.delete3),
    path('show/<int:nid>/edit1/', views.edit1),
    path('show/<int:nid>/edit2/', views.edit2),
    path('show/<int:nid>/edit3/', views.edit3),
    path('file1/', views.file1),
    path('file2/', views.file2),
    path('file3/', views.file3),
]
